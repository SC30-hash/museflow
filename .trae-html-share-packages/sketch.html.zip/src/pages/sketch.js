// src/pages/sketch.js
// 创作 page: Web Audio beat pads, melody keys, transport (play/stop), BPM and
// loop-length controls, and a live playhead on the loop timeline. Supports
// keyboard input (1-8 for pads, a-s-d-g-h-j for melody keys, space to play/stop).

import { mountNav, swapIcon, refreshIcons } from '../lib/nav.js';
import * as audio from '../lib/audio.js';
import { settings, sketches, nowstamp } from '../lib/store.js';

const toastEl = document.getElementById('toast');
let toastTimer = null;
window.MFToast = (msg) => {
  toastEl.textContent = msg;
  toastEl.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.remove('show'), 1800);
};

const stored = settings.all();
let bpm = stored.bpm || 110;
let beats = stored.beats || 4;
let metronomeOn = true;
audio.setMetronome(true);

const bpmDisplay = document.getElementById('bpm-display');
const beatsDisplay = document.getElementById('beats-display');
const playBtn = document.getElementById('play-btn');
const stopBtn = document.getElementById('stop-btn');
const beatReadout = document.getElementById('beat-readout');

audio.setBpm(bpm);
audio.setLoopLength(beats);
audio.onBeatEvent((step) => {
  updatePlayhead(step);
  const beat = Math.floor(step / 4) + 1;
  beatReadout.textContent = `第 ${beat} 拍 · 第 ${(step % 4) + 1}/16 步`;
});

function setBpm(v) {
  bpm = Math.max(40, Math.min(200, v));
  audio.setBpm(bpm);
  bpmDisplay.textContent = bpm;
  settings.save({ ...settings.all(), bpm });
  if (audio.isRunning()) { audio.stop(); audio.start(); }
}
function setBeats(n) {
  beats = Math.max(1, Math.min(16, n));
  audio.setLoopLength(beats);
  beatsDisplay.textContent = `${beats} 拍`;
  settings.save({ ...settings.all(), beats });
  buildRulers();
  renderTracks();
}
document.getElementById('bpm-up').addEventListener('click', () => setBpm(bpm + 1));
document.getElementById('bpm-down').addEventListener('click', () => setBpm(bpm - 1));
document.getElementById('beats-up').addEventListener('click', () => setBeats(beats + 1));
document.getElementById('beats-down').addEventListener('click', () => setBeats(beats - 1));

// ---- Beat pads ----
const pads = document.querySelectorAll('#beat-pads .beat-pad');
pads.forEach((pad) => {
  let armed = false;
  const trigger = () => {
    if (armed) return;
    armed = true;
    setTimeout(() => { armed = false; }, 60);
    const idx = Number(pad.dataset.pad);
    audio.hitPad(idx);
    audio.recordHit('pad', idx);
    flash(pad);
  };
  pad.addEventListener('pointerdown', (e) => { e.preventDefault(); trigger(); });
});
function flash(el) {
  el.classList.add('pad-active');
  // Also light up the inner icon/text for clearer feedback.
  const icon = el.querySelector('svg.lucide, i[data-lucide]');
  if (icon) icon.style.color = 'var(--museflow-primary-foreground)';
  const spans = el.querySelectorAll('span');
  spans.forEach((s) => (s.style.color = 'var(--museflow-primary-foreground)'));
  setTimeout(() => {
    el.classList.remove('pad-active');
    if (icon) icon.style.color = '';
    spans.forEach((s) => (s.style.color = ''));
  }, 480);
}

// ---- Chord pads (根音 + 模式可切换) ----
const chordGrid = document.getElementById('chord-pads');
const rootSelect = document.getElementById('root-select');
const modeMajorBtn = document.getElementById('mode-major');
const modeMinorBtn = document.getElementById('mode-minor');
let chordButtons = [];

function renderChords() {
  const chords = audio.currentChords();
  chordGrid.innerHTML = '';
  chordButtons = [];
  chords.forEach((ch, i) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.dataset.chord = i;
    btn.className =
      'chord-pad h-16 rounded-xl bg-muted hover:bg-primary/20 transition-colors duration-150 flex flex-col items-center justify-center gap-0.5';
    btn.setAttribute('aria-label', `和弦 ${ch.name}`);
    btn.innerHTML =
      `<span class="text-base font-semibold text-foreground leading-none">${ch.name}</span>` +
      `<span class="text-[10px] text-muted-foreground leading-none">${romanName(i, ch.name)}</span>`;
    const trigger = () => {
      if (btn._armed) return;
      btn._armed = true;
      setTimeout(() => { btn._armed = false; }, 60);
      audio.hitChord(i);
      audio.recordHit('chord', i);
      flash(btn);
    };
    btn.addEventListener('pointerdown', (e) => { e.preventDefault(); trigger(); });
    chordGrid.appendChild(btn);
    chordButtons.push(btn);
  });
}

// 给和弦垫一个罗马数字级数标记（I/ii/iii/IV/V/vi/V7），帮助理解调内功能。
function romanName(i, name) {
  const numerals = ['I', 'ii', 'iii', 'IV', 'V', 'V7'];
  return numerals[i] || '';
}

// 同步大调/小调按钮高亮样式
function syncModeButtons() {
  const mode = audio.getMode();
  const activeCls = 'bg-primary text-primary-foreground';
  const idleCls = 'text-muted-foreground';
  modeMajorBtn.className = `mode-btn px-2 py-1 rounded-sm text-xs font-medium transition-colors duration-150 ${mode === 'major' ? activeCls : idleCls}`;
  modeMinorBtn.className = `mode-btn px-2 py-1 rounded-sm text-xs font-medium transition-colors duration-150 ${mode === 'minor' ? activeCls : idleCls}`;
  modeMajorBtn.setAttribute('aria-pressed', String(mode === 'major'));
  modeMinorBtn.setAttribute('aria-pressed', String(mode === 'minor'));
}
// 切换模式（保留另一控件状态，互斥选择）
function setMode(mode) {
  audio.setMode(mode);
  syncModeButtons();
  renderChords();
  updatePlayhead(audio.getStep());
  window.MFToast(`已切换到 ${audio.currentKeyLabel()}`);
}
modeMajorBtn.addEventListener('pointerdown', (e) => { e.preventDefault(); setMode('major'); });
modeMinorBtn.addEventListener('pointerdown', (e) => { e.preventDefault(); setMode('minor'); });
rootSelect.addEventListener('change', () => {
  audio.setRoot(rootSelect.value);
  renderChords();
  updatePlayhead(audio.getStep());
  window.MFToast(`已切换到 ${audio.currentKeyLabel()}`);
});
syncModeButtons();

// ---- 和弦音色 / 演奏方式切换 ----
const voiceGroup = document.getElementById('voice-group');
const styleGroup = document.getElementById('style-group');

function syncVoiceButtons() {
  const current = audio.getChordVoice();
  const activeCls = 'bg-primary text-primary-foreground';
  const idleCls = 'text-muted-foreground';
  voiceGroup.querySelectorAll('.voice-btn').forEach((btn) => {
    btn.className = `voice-btn px-2 py-0.5 rounded-sm text-[11px] font-medium transition-colors ${btn.dataset.voice === current ? activeCls : idleCls}`;
  });
}
function syncStyleButtons() {
  const current = audio.getChordStyle();
  const activeCls = 'bg-primary text-primary-foreground';
  const idleCls = 'text-muted-foreground';
  styleGroup.querySelectorAll('.style-btn').forEach((btn) => {
    btn.className = `style-btn px-2 py-0.5 rounded-sm text-[11px] font-medium transition-colors ${btn.dataset.style === current ? activeCls : idleCls}`;
  });
}
voiceGroup.addEventListener('click', (e) => {
  const btn = e.target.closest('.voice-btn');
  if (!btn) return;
  audio.setChordVoice(btn.dataset.voice);
  syncVoiceButtons();
  window.MFToast(`音色：${btn.textContent}`);
});
styleGroup.addEventListener('click', (e) => {
  const btn = e.target.closest('.style-btn');
  if (!btn) return;
  audio.setChordStyle(btn.dataset.style);
  syncStyleButtons();
  window.MFToast(`演奏：${btn.textContent}`);
});
syncVoiceButtons();
syncStyleButtons();

// ---- 多音轨循环段 ----
// 一条音频 = 一条音轨：每次触发录制即新建一条音轨，记录该声音的步位。
// 视图：轨名 + 16 格条（命中格高亮，点击删除该声音）+ 整轨删除按钮。
const tracksList = document.getElementById('tracks-list');
const stepRuler = document.getElementById('step-ruler');
const playheadRuler = document.getElementById('playhead-ruler');

// 声音显示名：鼓垫用全名，和弦用和弦名
function trackName(tr) {
  if (tr.type === 'pad') return audio.voiceName(tr.idx) || `鼓 ${tr.idx + 1}`;
  const chords = audio.currentChords();
  return chords[tr.idx]?.name || `和弦 ${tr.idx + 1}`;
}
function trackIcon(tr) {
  return tr.type === 'pad' ? ['circle', 'x', 'drum', 'circle-dot'][tr.idx] || 'disc' : 'music';
}

// 构建步标尺（1-16 步号）+ 播放头条
function buildRulers() {
  const steps = audio.getStepsPerLoop();
  stepRuler.style.gridTemplateColumns = `repeat(${steps}, minmax(0, 1fr))`;
  playheadRuler.style.gridTemplateColumns = `repeat(${steps}, minmax(0, 1fr))`;
  stepRuler.innerHTML = '';
  playheadRuler.innerHTML = '';
  for (let i = 0; i < steps; i++) {
    const num = document.createElement('div');
    num.className = 'text-[9px] text-center text-muted-foreground/60';
    num.textContent = (i % 4 === 0) ? `${Math.floor(i / 4) + 1}` : '·';
    stepRuler.appendChild(num);
    const ph = document.createElement('div');
    ph.className = 'h-1 rounded-sm bg-muted/50';
    ph.dataset.step = i;
    playheadRuler.appendChild(ph);
  }
}

// 渲染音轨列表（步进轨 + 麦克风轨）
function renderTracks() {
  const tracks = audio.getTracks();
  const mics = audio.getMicTracks();
  const steps = audio.getStepsPerLoop();
  const hasAny = tracks.length || mics.length;
  if (!hasAny) {
    tracksList.innerHTML = `<div class="py-6 text-center text-xs text-muted-foreground/70">还没有音轨 — 开启"录"打节拍，或点"麦"录人声/乐器<br/><span class="opacity-70">拖动命中格可改位置，短按删除</span></div>`;
    return;
  }
  tracksList.innerHTML = '';
  // 步进轨：每个音色一行，含 16 格条
  tracks.forEach((tr) => {
    const row = document.createElement('div');
    row.className = 'flex items-center gap-2';
    row.dataset.trackId = tr.id;
    // 轨名（含图标）
    const name = document.createElement('div');
    name.className = 'w-14 shrink-0 flex items-center gap-1 text-[11px] font-medium text-foreground/90';
    name.innerHTML = `<i data-lucide="${trackIcon(tr)}" class="w-3 h-3 text-primary"></i><span class="truncate">${trackName(tr)}</span>`;
    row.appendChild(name);
    // 16 格条
    const bar = document.createElement('div');
    bar.className = 'flex-1 grid gap-px rounded-sm bg-surface-border';
    bar.style.gridTemplateColumns = `repeat(${steps}, minmax(0, 1fr))`;
    for (let i = 0; i < steps; i++) {
      const cell = document.createElement('button');
      cell.type = 'button';
      cell.dataset.step = i;
      cell.className = 'h-5 rounded-sm transition-colors duration-100';
      const beatIdx = Math.floor(i / 4);
      const isHit = tr.steps.includes(i);
      if (isHit) {
        cell.classList.add('bg-primary', 'hover:bg-destructive');
        cell.title = '拖动移动位置 · 短按删除';
        // 移动端拖拽需阻止默认触摸滚动
        cell.style.touchAction = 'none';
      } else {
        const alpha = beatIdx === 0 ? 0.22 : beatIdx % 2 === 1 ? 0.15 : 0.10;
        cell.style.backgroundColor = `rgba(229, 62, 62, ${alpha})`;
        cell.classList.add('hover:bg-primary/30');
      }
      bar.appendChild(cell);
    }
    row.appendChild(bar);
    // 整轨删除按钮
    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'w-6 h-6 shrink-0 rounded-md bg-muted hover:bg-destructive text-muted-foreground hover:text-destructive-foreground flex items-center justify-center transition-colors duration-150';
    del.title = '删除整条音轨';
    del.innerHTML = `<i data-lucide="trash-2" class="w-3 h-3"></i>`;
    row.appendChild(del);
    tracksList.appendChild(row);
  });
  // 麦克风轨：连续音频，用一条横条表示 + 时长 + 删除
  mics.forEach((m) => {
    const row = document.createElement('div');
    row.className = 'flex items-center gap-2';
    row.dataset.micId = m.id;
    const name = document.createElement('div');
    name.className = 'w-14 shrink-0 flex items-center gap-1 text-[11px] font-medium text-foreground/90';
    name.innerHTML = `<i data-lucide="mic" class="w-3 h-3 text-primary"></i><span class="truncate">${m.name}</span>`;
    row.appendChild(name);
    // 音频条（横条占满，渐变色表示连续音频）
    const bar = document.createElement('div');
    bar.className = 'flex-1 h-5 rounded-sm bg-primary/30 border border-primary/40 flex items-center px-2';
    bar.innerHTML = `<span class="text-[10px] text-primary/80">${m.duration.toFixed(1)}s 连续音频</span>`;
    row.appendChild(bar);
    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'w-6 h-6 shrink-0 rounded-md bg-muted hover:bg-destructive text-muted-foreground hover:text-destructive-foreground flex items-center justify-center transition-colors duration-150';
    del.title = '删除麦克风轨';
    del.innerHTML = `<i data-lucide="trash-2" class="w-3 h-3"></i>`;
    row.appendChild(del);
    tracksList.appendChild(row);
  });
  refreshIcons();
}

// 更新播放头（高亮所有轨当前步 + 底部游标）
function updatePlayhead(step) {
  // 各轨高亮当前步
  tracksList.querySelectorAll('[data-track-id]').forEach((row) => {
    const cells = row.querySelectorAll('button[data-step]');
    cells.forEach((c) => {
      const i = Number(c.dataset.step);
      const wasHit = c.classList.contains('bg-primary');
      c.style.outline = i === step ? '1px solid var(--museflow-primary)' : 'none';
      c.style.outlineOffset = i === step ? '1px' : '0';
      // 命中格在播放头时加亮
      if (wasHit) {
        c.style.filter = i === step ? 'brightness(1.4)' : '';
      }
    });
  });
  // 底部游标
  playheadRuler.querySelectorAll('div[data-step]').forEach((c) => {
    const i = Number(c.dataset.step);
    c.className = i === step
      ? 'h-1 rounded-sm bg-primary'
      : 'h-1 rounded-sm bg-muted/50';
  });
}

// 音轨区交互（FL Studio 风格）：
// - 点击空白格 → 直接添加一个命中步
// - 短按命中格 → 删除该命中步
// - 在命中格上按下并拖动 → 把该步移到指针所在的新步位（同轨内移动）
// - 点垃圾桶 → 删整条音轨（该音色全部命中）
let drag = null; // {trackId, startStep, startX, startY, moved, targetStep, row, pointerId, isHit}

tracksList.addEventListener('pointerdown', (e) => {
  // 麦克风轨：点删除按钮即删整轨
  const micRow = e.target.closest('[data-mic-id]');
  if (micRow) {
    if (e.target.closest('button[title*="删除麦克风"]')) {
      audio.removeMicTrack(micRow.dataset.micId);
      renderTracks();
      updatePlayhead(audio.getStep());
      window.MFToast('已删除麦克风轨');
    }
    return;
  }
  const row = e.target.closest('[data-track-id]');
  if (!row) return;
  const trackId = row.dataset.trackId;
  // 点删除按钮 → 删整轨
  if (e.target.closest('button[title*="删除整条"]')) {
    audio.removeTrack(trackId);
    renderTracks();
    updatePlayhead(audio.getStep());
    window.MFToast('已删除音轨');
    return;
  }
  const cell = e.target.closest('button[data-step]');
  if (!cell) return;
  e.preventDefault();
  const startStep = Number(cell.dataset.step);
  const isHit = cell.classList.contains('bg-primary');
  drag = {
    trackId, startStep, isHit,
    startX: e.clientX, startY: e.clientY,
    moved: false,
    targetStep: startStep,
    row,
    pointerId: e.pointerId,
    cell,
  };
  // 命中格拖拽时半透明；空白格按下时先预览高亮（提示可添加）
  if (isHit) {
    cell.style.opacity = '0.4';
  } else {
    cell.classList.add('ring-2', 'ring-primary');
  }
  if (cell.setPointerCapture) {
    try { cell.setPointerCapture(e.pointerId); } catch {}
  }
});

tracksList.addEventListener('pointermove', (e) => {
  if (!drag) return;
  // 阈值判断，区分点击 vs 拖动
  const dx = e.clientX - drag.startX;
  const dy = e.clientY - drag.startY;
  if (!drag.moved && Math.hypot(dx, dy) > 6) drag.moved = true;
  if (!drag.moved) return;
  // 找到指针当前所在的格
  const el = document.elementFromPoint(e.clientX, e.clientY);
  const targetCell = el?.closest?.('button[data-step]');
  // 清除之前的目标高亮（保留被拖格的半透明）
  drag.row.querySelectorAll('button[data-step]').forEach((c) => {
    if (c !== drag.cell) c.classList.remove('ring-2', 'ring-primary');
  });
  if (targetCell && drag.row.contains(targetCell)) {
    const t = Number(targetCell.dataset.step);
    drag.targetStep = t;
    if (targetCell !== drag.cell) targetCell.classList.add('ring-2', 'ring-primary');
  } else {
    drag.targetStep = drag.startStep;
  }
});

function endDrag(commit) {
  if (!drag) return;
  const { trackId, startStep, isHit, moved, targetStep, row, cell } = drag;
  // 清除拖拽/预览样式
  row.querySelectorAll('button[data-step]').forEach((c) => {
    c.style.opacity = '';
    c.classList.remove('ring-2', 'ring-primary');
  });
  drag = null;
  if (!commit) return; // pointercancel 不提交
  if (!moved) {
    // 短按原位
    if (isHit) {
      // 短按命中格 → 删除该步
      audio.removeTrackHit(trackId, startStep);
      renderTracks();
      updatePlayhead(audio.getStep());
      window.MFToast('已删除该步');
    } else {
      // 短按空白格 → 添加该步并播放对应音色
      audio.addTrackHit(trackId, startStep);
      playTrack(trackId);
      renderTracks();
      updatePlayhead(audio.getStep());
      window.MFToast('已添加该步');
    }
  } else if (isHit && targetStep !== startStep) {
    // 命中格拖到新位置 → 移动该步
    audio.moveTrackHit(trackId, startStep, targetStep);
    renderTracks();
    updatePlayhead(audio.getStep());
    window.MFToast(`已移动到第 ${targetStep + 1} 步`);
  } else if (!isHit && targetStep !== startStep) {
    // 空白格拖到另一格 → 在目标格添加并播放对应音色
    audio.addTrackHit(trackId, targetStep);
    playTrack(trackId);
    renderTracks();
    updatePlayhead(audio.getStep());
    window.MFToast(`已添加到第 ${targetStep + 1} 步`);
  }
}

// 触发某条音轨对应的音色（添加步位时给即时听觉反馈）
function playTrack(trackId) {
  const tr = audio.getTrack(trackId);
  if (!tr) return;
  audio.resume();
  if (tr.type === 'pad') audio.hitPad(tr.idx);
  else if (tr.type === 'chord') audio.hitChord(tr.idx);
}
tracksList.addEventListener('pointerup', () => endDrag(true));
tracksList.addEventListener('pointercancel', () => endDrag(false));

buildRulers();
renderTracks();
// 音轨状态变化时（录制/删除）自动重渲染
audio.onLoopState(() => {
  renderTracks();
  updatePlayhead(audio.getStep());
});

// ---- Loop 录制 / 回放 / 清除 ----
const micBtn = document.getElementById('mic-btn');
const recBtn = document.getElementById('rec-btn');
const loopBtn = document.getElementById('loop-btn');
const clearBtn = document.getElementById('clear-btn');

function syncLoopButtons() {
  const mic = audio.isMicRecOn();
  const rec = audio.isRecOn();
  const loop = audio.isLoopOn();
  micBtn.setAttribute('aria-pressed', String(mic));
  recBtn.setAttribute('aria-pressed', String(rec));
  loopBtn.setAttribute('aria-pressed', String(loop));
  // 麦克风录音中用红色脉冲样式
  micBtn.className = mic
    ? 'px-2.5 py-1.5 rounded-lg bg-destructive text-destructive-foreground text-xs font-medium flex items-center gap-1.5 animate-pulse'
    : 'px-2.5 py-1.5 rounded-lg bg-muted text-xs font-medium text-muted-foreground flex items-center gap-1.5 hover:text-foreground transition-colors duration-150';
  recBtn.className = rec
    ? 'px-2.5 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-medium flex items-center gap-1.5'
    : 'px-2.5 py-1.5 rounded-lg bg-muted text-xs font-medium text-muted-foreground flex items-center gap-1.5 hover:text-foreground transition-colors duration-150';
  loopBtn.className = loop
    ? 'px-2.5 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-medium flex items-center gap-1.5'
    : 'px-2.5 py-1.5 rounded-lg bg-muted text-xs font-medium text-muted-foreground flex items-center gap-1.5 hover:text-foreground transition-colors duration-150';
}
audio.onLoopState(syncLoopButtons);

recBtn.addEventListener('pointerdown', (e) => {
  e.preventDefault();
  if (audio.isRecOn()) audio.stopRecording();
  else audio.startRecording();
  syncLoopButtons();
  window.MFToast(audio.isRecOn() ? '录制中，点垫/和弦录入' : '已停止录制');
});
// 麦克风录音：开 = 申请麦克风权限开始录；停 = 转成 AudioBuffer 存为新轨
micBtn.addEventListener('pointerdown', async (e) => {
  e.preventDefault();
  await audio.resume();
  if (audio.isMicRecOn()) {
    window.MFToast('正在保存录音…');
    const id = await audio.stopMicRecording();
    if (id) {
      window.MFToast('已生成麦克风轨');
      renderTracks();
    } else {
      window.MFToast('录音保存失败');
    }
  } else {
    const ok = await audio.startMicRecording();
    syncLoopButtons();
    if (ok) window.MFToast('麦克风录音中，再点结束');
    else window.MFToast('无法访问麦克风');
  }
});
loopBtn.addEventListener('pointerdown', (e) => {
  e.preventDefault();
  audio.setLooping(!audio.isLoopOn());
  syncLoopButtons();
  window.MFToast(audio.isLoopOn() ? '循环回放已开' : '循环回放已关');
});
clearBtn.addEventListener('pointerdown', (e) => {
  e.preventDefault();
  audio.clearLoop();
  updatePlayhead(audio.getStep());
  window.MFToast('已清空循环');
});
syncLoopButtons();

// ---- Transport ----
function clearPlayhead() {
  // 清除各轨单格 outline + 底部游标
  tracksList.querySelectorAll('button[data-step]').forEach((c) => { c.style.outline = 'none'; c.style.filter = ''; });
  playheadRuler.querySelectorAll('div[data-step]').forEach((c) => { c.className = 'h-1 rounded-sm bg-muted/50'; });
}
function togglePlay() {
  if (audio.isRunning()) {
    audio.stop();
    swapIcon(playBtn, 'play');
    beatReadout.textContent = '已停止';
    clearPlayhead();
  } else {
    audio.start();
    swapIcon(playBtn, 'pause');
  }
}
playBtn.addEventListener('click', togglePlay);
stopBtn.addEventListener('click', () => {
  audio.stop();
  swapIcon(playBtn, 'play');
  beatReadout.textContent = '已停止';
  clearPlayhead();
});

// ---- Settings popover ----
const popover = document.getElementById('settings-popover');
document.getElementById('settings-btn').addEventListener('click', () => popover.classList.remove('hidden'));
popover.addEventListener('click', (e) => {
  const t = e.target;
  if (t && typeof t.matches === 'function' && (t.matches('[data-close]') || t.closest('[data-close]'))) {
    popover.classList.add('hidden');
  }
});
document.getElementById('master-vol').addEventListener('input', (e) => {
  const val = parseFloat(e.target.value);
  audio.setMasterVolume(val);
});
document.getElementById('metronome-toggle').addEventListener('change', (e) => {
  metronomeOn = e.target.checked;
  audio.setMetronome(metronomeOn);
  window.MFToast(metronomeOn ? '节拍器已开' : '节拍器已关');
});

// ---- Keyboard shortcuts ----
const PAD_KEYS = ['1', '2', '3', '4'];
const CHORD_KEYS = { a: 0, s: 1, d: 2, g: 3, h: 4, j: 5 };
window.addEventListener('keydown', (e) => {
  const t = e.target;
  if (t && typeof t.matches === 'function' && t.matches('input, textarea, select')) return;
  if (e.key === ' ') { e.preventDefault(); togglePlay(); return; }
  const pi = PAD_KEYS.indexOf(e.key);
  if (pi >= 0 && pads[pi]) {
    audio.hitPad(pi);
    audio.recordHit('pad', pi);
    flash(pads[pi]);
    return;
  }
  const ci = CHORD_KEYS[e.key.toLowerCase()];
  if (ci !== undefined && chordButtons[ci]) {
    audio.hitChord(ci);
    audio.recordHit('chord', ci);
    flash(chordButtons[ci]);
  }
});

// Init
mountNav('sketch');
bpmDisplay.textContent = bpm;
beatsDisplay.textContent = `${beats} 拍`;
renderChords();

// ---- 保存循环段 / 导出 WAV / 已保存列表 ----
const saveSketchBtn = document.getElementById('save-sketch-btn');
const exportSketchBtn = document.getElementById('export-sketch-btn');
const savedSection = document.getElementById('saved-sketches-section');
const savedList = document.getElementById('saved-sketches-list');
const savedCount = document.getElementById('saved-sketches-count');

const sketchesToggleSelectBtn = document.getElementById('sketches-toggle-select');
const sketchesSelectBar = document.getElementById('sketches-select-bar');
const sketchesSelectAll = document.getElementById('sketches-select-all');
const sketchesSelectedCount = document.getElementById('sketches-selected-count');
const sketchesBatchDeleteBtn = document.getElementById('sketches-batch-delete');
const sketchesSelectCancelBtn = document.getElementById('sketches-select-cancel');

let sketchesSelectMode = false;
let sketchesSelected = new Set();

// ================== 确认弹框（通用） ==================
const confirmModal = document.getElementById('confirm-modal');
const confirmMessage = document.getElementById('confirm-message');
let confirmResolver = null;
function openConfirm(message) {
  confirmMessage.textContent = message || '确认继续？';
  confirmModal.style.display = 'flex';
  refreshIcons();
  return new Promise((resolve) => { confirmResolver = resolve; });
}
function closeConfirm(result) {
  confirmModal.style.display = 'none';
  if (confirmResolver) { confirmResolver(!!result); confirmResolver = null; }
}
document.getElementById('confirm-cancel')?.addEventListener('click', () => closeConfirm(false));
document.getElementById('confirm-ok')?.addEventListener('click', () => closeConfirm(true));
confirmModal?.addEventListener('click', (e) => { if (e.target === confirmModal) closeConfirm(false); });
document.addEventListener('keydown', (e) => {
  if (confirmModal && confirmModal.style.display === 'flex') {
    if (e.key === 'Escape') closeConfirm(false);
    if (e.key === 'Enter') closeConfirm(true);
  }
});

function updateSketchesSelectUI() {
  const items = sketches.all();
  if (!sketchesSelectMode) {
    sketchesSelectBar?.classList.add('hidden');
    sketchesToggleSelectBtn?.classList.remove('bg-muted', 'text-foreground');
  } else {
    sketchesSelectBar?.classList.remove('hidden');
    sketchesToggleSelectBtn?.classList.add('bg-muted', 'text-foreground');
  }
  if (sketchesSelectedCount) sketchesSelectedCount.textContent = `已选 ${sketchesSelected.size} 项`;
  if (sketchesBatchDeleteBtn) sketchesBatchDeleteBtn.disabled = sketchesSelected.size === 0;
  if (sketchesSelectAll) {
    sketchesSelectAll.checked = items.length > 0 && sketchesSelected.size === items.length;
    sketchesSelectAll.indeterminate = sketchesSelected.size > 0 && sketchesSelected.size < items.length;
  }
}

function exitSketchesSelectMode() {
  sketchesSelectMode = false;
  sketchesSelected.clear();
  const items = sketches.all();
  sketchesSelectBar?.classList.add('hidden');
  sketchesToggleSelectBtn?.classList.remove('bg-muted', 'text-foreground');
  if (sketchesSelectedCount) sketchesSelectedCount.textContent = '已选 0 项';
  if (sketchesBatchDeleteBtn) sketchesBatchDeleteBtn.disabled = true;
  if (sketchesSelectAll) { sketchesSelectAll.checked = false; sketchesSelectAll.indeterminate = false; }
  if (items.length === 0) return;
  renderSavedSketches();
}

function hasContent() {
  const t = audio.getTracks();
  const m = audio.getMicTracks();
  return t.length > 0 || m.length > 0;
}

function renderSavedSketches() {
  const list = sketches.all();
  savedCount.textContent = `${list.length} 个循环段`;
  if (list.length === 0) {
    exitSketchesSelectMode();
    savedSection.style.display = 'none';
    return;
  }
  savedSection.style.display = '';
  savedList.innerHTML = '';
  list.forEach((sk) => {
    const checked = sketchesSelected.has(sk.id);
    const row = document.createElement('div');
    row.className = `flex items-center gap-3 p-2.5 rounded-xl border border-border/50 transition-all duration-150 ${checked ? 'bg-primary/10 border-primary ring-2 ring-primary/30' : 'bg-muted/50'}`;
    row.dataset.id = sk.id;

    if (sketchesSelectMode) {
      const box = document.createElement('label');
      box.className = `shrink-0 w-5 h-5 rounded-md border-2 border-border flex items-center justify-center cursor-pointer hover:border-primary transition-colors ${checked ? 'bg-primary border-primary' : ''}`;
      box.onclick = (e) => { e.stopPropagation(); };
      box.dataset.sketchCheck = sk.id;
      box.innerHTML = `<i data-lucide="check" class="w-3.5 h-3.5 ${checked ? 'text-primary-foreground' : 'text-transparent'}"></i>`;
      box.addEventListener('click', () => {
        if (sketchesSelected.has(sk.id)) sketchesSelected.delete(sk.id);
        else sketchesSelected.add(sk.id);
        updateSketchesSelectUI();
        renderSavedSketches();
      });
      row.appendChild(box);
    }

    const left = document.createElement('div');
    left.className = 'w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0';
    left.innerHTML = `<i data-lucide="disc" class="w-4 h-4 text-primary"></i>`;
    const info = document.createElement('div');
    info.className = 'flex-1 min-w-0';
    info.innerHTML = `<p class="text-sm font-medium truncate">${sk.title}</p>
      <p class="text-[11px] text-muted-foreground">${sk.date} · ${sk.bpm} BPM · ${sk.beats} 拍 · ${sk.trackCount} 轨</p>`;

    if (!sketchesSelectMode) {
      const actions = document.createElement('div');
      actions.className = 'flex items-center gap-1';
      const playBtn = document.createElement('button');
      playBtn.type = 'button';
      playBtn.className = 'p-1.5 rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors';
      playBtn.innerHTML = `<i data-lucide="play" class="w-4 h-4"></i>`;
      playBtn.title = '播放';
      playBtn.addEventListener('click', () => {
        window.MFToast('已恢复循环段');
        restoreSketch(sk);
      });
      const dlBtn = document.createElement('button');
      dlBtn.type = 'button';
      dlBtn.className = 'p-1.5 rounded-md text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors';
      dlBtn.innerHTML = `<i data-lucide="download" class="w-4 h-4"></i>`;
      dlBtn.title = '导出 WAV';
      dlBtn.addEventListener('click', () => downloadSketch(sk));
      const delBtn = document.createElement('button');
      delBtn.type = 'button';
      delBtn.className = 'p-1.5 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors';
      delBtn.innerHTML = `<i data-lucide="trash-2" class="w-4 h-4"></i>`;
      delBtn.title = '删除';
      delBtn.addEventListener('click', () => {
        sketches.remove(sk.id);
        renderSavedSketches();
        window.MFToast('已删除');
      });
      actions.appendChild(playBtn);
      actions.appendChild(dlBtn);
      actions.appendChild(delBtn);
      row.appendChild(left);
      row.appendChild(info);
      row.appendChild(actions);
    } else {
      row.appendChild(left);
      row.appendChild(info);
    }
    savedList.appendChild(row);
  });
  updateSketchesSelectUI();
  refreshIcons();
}

// ---- 多选绑定 ----
if (sketchesToggleSelectBtn) {
  sketchesToggleSelectBtn.addEventListener('click', () => {
    const items = sketches.all();
    if (!items.length) { window.MFToast('暂无可选的循环段'); return; }
    sketchesSelectMode = !sketchesSelectMode;
    if (!sketchesSelectMode) sketchesSelected.clear();
    updateSketchesSelectUI();
    renderSavedSketches();
  });
}
if (sketchesSelectCancelBtn) {
  sketchesSelectCancelBtn.addEventListener('click', exitSketchesSelectMode);
}
if (sketchesSelectAll) {
  sketchesSelectAll.addEventListener('change', () => {
    const items = sketches.all();
    if (sketchesSelectAll.checked) sketchesSelected = new Set(items.map((x) => x.id));
    else sketchesSelected.clear();
    updateSketchesSelectUI();
    renderSavedSketches();
  });
}
if (sketchesBatchDeleteBtn) {
  sketchesBatchDeleteBtn.addEventListener('click', async () => {
    if (!sketchesSelected.size) return;
    const ok = await openConfirm(`确定删除选中的 ${sketchesSelected.size} 个循环段？此操作不可恢复。`);
    if (!ok) return;
    let n = 0;
    sketchesSelected.forEach((id) => { sketches.remove(id); n++; });
    window.MFToast(`已删除 ${n} 个循环段`);
    exitSketchesSelectMode();
  });
}

// 把当前 loop 状态序列化保存
function captureLoopState() {
  const tracks = audio.getTracks();
  const mics = audio.getMicTracks();
  return {
    tracks,
    mics: mics.map((m) => ({ id: m.id, name: m.name, duration: m.duration })),
  };
}

// 恢复循环段到当前工程（只恢复步进音轨，麦克风轨不恢复到内存）
function restoreSketch(sk) {
  // 清空当前 loop，重建音轨
  audio.clearLoop();
  // 通过 addTrackHit / 手动恢复
  if (sk.state && sk.state.tracks) {
    sk.state.tracks.forEach((tr) => {
      tr.steps.forEach((step) => {
        // 找或创建对应轨
        const existing = audio.getTracks().find((t) => t.type === tr.type && t.idx === tr.idx);
        if (existing) {
          audio.addTrackHit(existing.id, step);
        } else {
          // 需要先创建轨：触发一次音色再加入步
          // 临时方案：创建一个假轨
          audio.resume();
          if (tr.type === 'pad') audio.hitPad(tr.idx);
          else audio.hitChord(tr.idx);
          // 等待 getTracks 返回后添加
          setTimeout(() => {
            const nt = audio.getTracks().find((t) => t.type === tr.type && t.idx === tr.idx);
            if (nt) tr.steps.forEach((s) => audio.addTrackHit(nt.id, s));
          }, 50);
        }
      });
    });
  }
  // 恢复 BPM / 拍数
  if (sk.bpm) setBpm(sk.bpm);
  if (sk.beats) setBeats(sk.beats);
  window.MFToast('循环段已恢复');
}

// 下载已保存 sketch 的音频（如果有 blob）
function downloadSketch(sk) {
  if (sk.audioBlob) {
    const url = URL.createObjectURL(sk.audioBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${sk.title}.wav`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    window.MFToast('开始下载 WAV');
  } else {
    window.MFToast('暂无音频文件');
  }
}

// 保存按钮：命名 → 保存状态 → 可选导出音频
saveSketchBtn.addEventListener('click', async () => {
  if (!hasContent()) {
    window.MFToast('循环段为空，先录点东西');
    return;
  }
  const title = await promptForName('保存循环段', '给这个循环段起个名字');
  if (title === null) return; // 取消
  const tracks = audio.getTracks();
  const mics = audio.getMicTracks();
  const item = {
    title,
    bpm,
    beats,
    trackCount: tracks.length + mics.length,
    date: nowstamp(),
    state: captureLoopState(),
    audioBlob: null, // 懒加载：需要时再导出
  };
  sketches.add(item);
  renderSavedSketches();
  window.MFToast('已保存');
});

// 导出 WAV 按钮
exportSketchBtn.addEventListener('click', async () => {
  if (!hasContent()) {
    window.MFToast('循环段为空');
    return;
  }
  window.MFToast('正在渲染 WAV…');
  try {
    const blob = await audio.exportLoopAsWav();
    if (!blob) {
      window.MFToast('导出失败');
      return;
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const ts = new Date().toISOString().replace(/[:.]/g, '-');
    a.download = `sketch_${bpm}bpm_${ts}.wav`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    window.MFToast('WAV 已下载');
  } catch (e) {
    console.error(e);
    window.MFToast('导出出错');
  }
});

// 简单的命名 prompt（替换原生）
function promptForName(title, placeholder) {
  return new Promise((resolve) => {
    // 创建模态框
    const overlay = document.createElement('div');
    overlay.className = 'fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm';
    overlay.innerHTML = `
      <div class="bg-popover border border-border rounded-xl p-5 w-80 shadow-2xl">
        <h3 class="text-sm font-semibold mb-3 text-popover-foreground">${title}</h3>
        <input type="text" class="w-full px-3 py-2 rounded-md bg-input border border-border text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary" placeholder="${placeholder}" maxlength="60" />
        <div class="mt-4 flex items-center justify-end gap-2">
          <button type="button" class="px-3 py-1.5 rounded-md border border-border text-xs text-muted-foreground hover:text-foreground cancel-btn">取消</button>
          <button type="button" class="px-3 py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-medium confirm-btn">保存</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    const input = overlay.querySelector('input');
    input.focus();
    const cleanup = (val) => { document.body.removeChild(overlay); resolve(val); };
    overlay.querySelector('.cancel-btn').addEventListener('click', () => cleanup(null));
    overlay.querySelector('.confirm-btn').addEventListener('click', () => cleanup(input.value.trim() || '未命名循环段'));
    overlay.addEventListener('click', (e) => { if (e.target === overlay) cleanup(null); });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') cleanup(input.value.trim() || '未命名循环段');
      if (e.key === 'Escape') cleanup(null);
    });
  });
}

renderSavedSketches();
